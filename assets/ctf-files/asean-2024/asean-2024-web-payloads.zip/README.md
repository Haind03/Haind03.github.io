# ASEAN Student Contest 2024 - Attack-Defense web payloads

Exploit scripts for the two web services in the 2024 A&D final.

- `pepeviewer_exploit.py` - pepeviewer (PHP). Upload a PHP file through `home.php`,
  read the PHP session file through the LFI in `viewer.php?url=file:///tmp/sess_...`
  to recover the upload directory, then request the uploaded file to run `/readflag`.
  Loops over every team and submits the flags.
- `linkextractor_exploit.py` - Linkextractor 2.0 (Java). Log in, then post a page
  whose HTML links to `file:///flag1_linkextractor`. The service fetches it, renders
  the result as an image, and the flag is read back with OCR. This is the one where
  the OCR kept confusing `0` and `O`.

The game server address is dead and the team token has been removed. The challenge
binaries (`html.rar` for pepeviewer, `linkextractor.jar`) are the organizer's.
